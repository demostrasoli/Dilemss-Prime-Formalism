# Dilemss Formalism Project

This folder contains a draft mathematical research project around the Dilemss formalism for prime numbers.

## Files

- `Dilemss_Formalismus_Paper.tex`  
  LaTeX manuscript with definitions, proved lemmas, conditional propositions, and conjectures.

- `dilemss_analysis.py`  
  Reproducible numerical experiments for the Dilemss kernel, ideal prime positions, RH-scale errors, weighted gaps, and finite differences.

- `Dilemss_Action_Plan.txt`  
  Structured action plan for extending the project.

- `requirements.txt`  
  Python dependencies.

## Run the numerical experiment

```bash
python dilemss_analysis.py --N 100 --rmax 20 --precision 80 --outdir dilemss_outputs
```

The output directory will contain CSV tables and four PNG plots.

## Important interpretation note

The project does not claim to prove the Riemann Hypothesis, Cramer's conjecture, or any unresolved theorem on primes in short intervals. The manuscript separates proved lemmas, conditional propositions, heuristics, and conjectures.
