#!/usr/bin/env python3
"""
Numerical experiments for the Dilemss formalism.

Objects implemented:
  Phi(x) = x (digamma(x) + EulerGamma)
  L(x)   = int_2^x dt/log(t) = li(x) - li(2)
  P(n)   = L^{-1}(n-1)
  E_n    = Phi(p_n) - Phi(P(n))
  normalized finite differences D_r X_n = 2^{-r} Delta^r X_n

Default run:
  python dilemss_analysis.py --N 100 --rmax 20

Outputs are written to --outdir (default: dilemss_outputs):
  - dilemss_summary.csv
  - K_RH_running.csv
  - K_gap_alpha.csv
  - four PNG plots

Notes:
  High-order finite differences are numerically delicate because of cancellation.
  The code uses mpmath with configurable precision. Increase --precision if you
  push N or rmax much higher.
"""

from __future__ import annotations

import argparse
import csv
import math
import os
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Tuple

import mpmath as mp

try:
    from scipy.optimize import brentq as _scipy_brentq
    from scipy.special import expi as _scipy_expi
    _HAVE_SCIPY = True
except Exception:  # pragma: no cover - fallback path
    _scipy_brentq = None
    _scipy_expi = None
    _HAVE_SCIPY = False


def sieve_primes_count(count: int) -> List[int]:
    """Return the first `count` primes using a simple growing sieve."""
    if count < 1:
        return []
    if count == 1:
        return [2]

    # Dusart-like generous upper bound for n >= 6: n(log n + log log n)
    if count < 6:
        limit = 15
    else:
        n = float(count)
        limit = int(n * (math.log(n) + math.log(math.log(n))) + 20)

    while True:
        sieve = bytearray(b"\x01") * (limit + 1)
        sieve[0:2] = b"\x00\x00"
        root = int(limit ** 0.5)
        for p in range(2, root + 1):
            if sieve[p]:
                start = p * p
                sieve[start : limit + 1 : p] = b"\x00" * (((limit - start) // p) + 1)
        primes = [i for i, flag in enumerate(sieve) if flag]
        if len(primes) >= count:
            return primes[:count]
        limit *= 2


def L_of_x(x: mp.mpf) -> mp.mpf:
    """Offset logarithmic integral L(x)=li(x)-li(2), x >= 2."""
    # li(x)=Ei(log x) for x>1.  mp.ei(mp.log(x)) is usually faster than mp.li(x).
    return mp.ei(mp.log(x)) - mp.ei(mp.log(mp.mpf(2)))


def _L_float(x: float) -> float:
    """Fast double-precision offset logarithmic integral."""
    if not _HAVE_SCIPY:
        return float(L_of_x(mp.mpf(x)))
    return float(_scipy_expi(math.log(x)) - _scipy_expi(math.log(2.0)))


def inverse_L_values(N: int) -> List[mp.mpf]:
    """Compute P(n)=L^{-1}(n-1) for n=1,...,N.

    The default path uses scipy's brentq in double precision, then converts to
    mpmath.  This is fast and sufficient for the exploratory finite-prefix
    computations in this script.  If scipy is unavailable, a mpmath bisection
    fallback is used.
    """
    values: List[mp.mpf] = []

    if _HAVE_SCIPY:
        prev = 2.0
        for n in range(1, N + 1):
            target = float(n - 1)
            if n == 1:
                values.append(mp.mpf(2))
                prev = 2.0
                continue

            low = prev
            if n < 6:
                high = 15.0
            else:
                nf = float(n)
                high = nf * (math.log(nf) + math.log(math.log(nf))) + 20.0
                if high <= low:
                    high = low + 10.0
            while _L_float(high) < target:
                high *= 2.0

            root = _scipy_brentq(lambda z: _L_float(z) - target, low, high, xtol=1e-13, rtol=1e-13, maxiter=100)
            prev = root
            values.append(mp.mpf(str(root)))
        return values

    # Fallback: pure mpmath bisection.
    prev_mp = mp.mpf(2)
    for n in range(1, N + 1):
        target = mp.mpf(n - 1)
        if n == 1:
            values.append(mp.mpf(2))
            prev_mp = mp.mpf(2)
            continue

        low = prev_mp
        if n < 6:
            high = mp.mpf(15)
        else:
            nf = mp.mpf(n)
            high = nf * (mp.log(nf) + mp.log(mp.log(nf))) + 20
            if high <= low:
                high = low + 10
        while L_of_x(high) < target:
            high *= 2
        for _ in range(90):
            mid = (low + high) / 2
            if L_of_x(mid) < target:
                low = mid
            else:
                high = mid
        prev_mp = (low + high) / 2
        values.append(prev_mp)
    return values


def Phi(x: mp.mpf) -> mp.mpf:
    """Dilemss kernel Phi(x)=x(digamma(x)+gamma)."""
    x = mp.mpf(x)
    return x * (mp.digamma(x) + mp.euler)


def norm_delta(seq: Sequence[mp.mpf], start: int, r: int) -> mp.mpf:
    """Compute 2^{-r} Delta^r seq[start]. Zero-based indexing."""
    total = mp.mpf("0")
    for j in range(r + 1):
        coeff = mp.binomial(r, j)
        if (r - j) % 2:
            coeff = -coeff
        total += coeff * seq[start + j]
    return total / (mp.mpf(2) ** r)




def normalized_diff_levels(seq: Sequence[mp.mpf], rmax: int) -> List[List[mp.mpf]]:
    """Return levels[r][i] = 2^{-r} Delta^r seq[i]."""
    if not seq:
        return []
    rmax = min(rmax, len(seq) - 1)
    levels: List[List[mp.mpf]] = [list(seq)]
    for _ in range(1, rmax + 1):
        prev = levels[-1]
        levels.append([(prev[i + 1] - prev[i]) / 2 for i in range(len(prev) - 1)])
    return levels

def compute_K_RH(E: Sequence[mp.mpf], A: Sequence[mp.mpf], rmax: int) -> Tuple[mp.mpf, Tuple[int, int, mp.mpf]]:
    """Return max ratio and argmax (n, r, signed value), using one-based n."""
    levels = normalized_diff_levels(E, rmax)
    best_ratio = mp.mpf("0")
    best = (1, 0, mp.mpf("0"))
    for r, vals in enumerate(levels):
        for i, val in enumerate(vals):
            ratio = abs(val) / A[i + r]
            if ratio > best_ratio:
                best_ratio = ratio
                best = (i + 1, r, val)
    return best_ratio, best


def running_K_RH(E: Sequence[mp.mpf], A: Sequence[mp.mpf], rmax: int) -> List[Tuple[int, mp.mpf]]:
    """Running prefix K_RH over first M points."""
    N = len(E)
    levels = normalized_diff_levels(E, rmax)
    rows: List[Tuple[int, mp.mpf]] = []
    for M in range(1, N + 1):
        best = mp.mpf("0")
        max_r = min(rmax, M - 1)
        for r in range(max_r + 1):
            vals = levels[r]
            for i in range(0, M - r):
                ratio = abs(vals[i]) / A[i + r]
                if ratio > best:
                    best = ratio
        rows.append((M, best))
    return rows


def compute_K_gap(V: Sequence[mp.mpf], primes: Sequence[int], alpha: float, rmax: int) -> Tuple[mp.mpf, Tuple[int, int, mp.mpf]]:
    """Gap Dilemss norm for V_n=Phi(p_{n+1})-Phi(p_n), one-based n in report."""
    levels = normalized_diff_levels(V, rmax)
    a = mp.mpf(str(alpha))
    best_ratio = mp.mpf("0")
    best = (1, 0, mp.mpf("0"))
    for r, vals in enumerate(levels):
        for i, val in enumerate(vals):
            denom = mp.log(primes[i + r + 1]) ** (mp.mpf(2) + a)
            ratio = abs(val) / denom
            if ratio > best_ratio:
                best_ratio = ratio
                best = (i + 1, r, val)
    return best_ratio, best


def mp_to_float(x: mp.mpf) -> float:
    try:
        return float(x)
    except OverflowError:
        return math.inf if x > 0 else -math.inf


def write_csv(path: str, header: Sequence[str], rows: Iterable[Sequence[object]]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for row in rows:
            writer.writerow(row)


@dataclass
class ExperimentResult:
    primes: List[int]
    P: List[mp.mpf]
    phi_p: List[mp.mpf]
    phi_P: List[mp.mpf]
    E: List[mp.mpf]
    A: List[mp.mpf]
    V: List[mp.mpf]
    W: List[mp.mpf]


def run_experiment(N: int, rmax: int, precision: int, outdir: str, alphas: Sequence[float]) -> Dict[str, object]:
    mp.mp.dps = precision
    os.makedirs(outdir, exist_ok=True)

    primes = sieve_primes_count(N)
    P = inverse_L_values(N)
    phi_p = [Phi(mp.mpf(p)) for p in primes]
    phi_P = [Phi(x) for x in P]
    E = [a - b for a, b in zip(phi_p, phi_P)]
    A = [mp.sqrt(x) * (mp.log(x) ** 3) for x in P]
    V = [phi_p[i + 1] - phi_p[i] for i in range(N - 1)]
    W = [V[i] / (mp.log(primes[i]) ** 2) for i in range(N - 1)]

    K_RH, arg_RH = compute_K_RH(E, A, rmax)
    running = running_K_RH(E, A, rmax)
    gap_rows = []
    K_gaps = {}
    for alpha in alphas:
        K_gap, arg_gap = compute_K_gap(V, primes, alpha, rmax)
        K_gaps[alpha] = (K_gap, arg_gap)
        gap_rows.append([alpha, mp.nstr(K_gap, 30), arg_gap[0], arg_gap[1], mp.nstr(arg_gap[2], 30)])

    # Main summary table.
    summary_rows = []
    for i in range(N):
        gap = primes[i + 1] - primes[i] if i + 1 < N else ""
        Vi = V[i] if i < N - 1 else ""
        Wi = W[i] if i < N - 1 else ""
        summary_rows.append([
            i + 1,
            primes[i],
            mp.nstr(P[i], 30),
            mp.nstr(phi_p[i], 30),
            mp.nstr(phi_P[i], 30),
            mp.nstr(E[i], 30),
            mp.nstr(A[i], 30),
            mp.nstr(E[i] / A[i], 30),
            gap,
            mp.nstr(Vi, 30) if Vi != "" else "",
            mp.nstr(Wi, 30) if Wi != "" else "",
        ])

    write_csv(
        os.path.join(outdir, "dilemss_summary.csv"),
        ["n", "p_n", "P_n", "Phi_pn", "Phi_Pn", "E_n", "A_n", "E_over_A", "gap_gn", "V_n", "W_n"],
        summary_rows,
    )
    write_csv(
        os.path.join(outdir, "K_RH_running.csv"),
        ["M", "K_RH_prefix"],
        [[M, mp.nstr(v, 30)] for M, v in running],
    )
    write_csv(
        os.path.join(outdir, "K_gap_alpha.csv"),
        ["alpha", "K_gap", "arg_n", "arg_r", "signed_value"],
        gap_rows,
    )

    # Plots.
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    xs = list(range(1, N + 1))
    ratio_p = [(mp.mpf(primes[i]) - P[i]) / (mp.sqrt(P[i]) * (mp.log(P[i]) ** 2)) for i in range(N)]
    ratio_e = [E[i] / A[i] for i in range(N)]

    plt.figure()
    plt.plot(xs, [mp_to_float(v) for v in ratio_p], marker="o", linewidth=1)
    plt.xlabel("n")
    plt.ylabel("(p_n - P(n)) / (sqrt(P(n)) log(P(n))^2)")
    plt.title("Prime-position error on RH scale")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "prime_position_error_RH_scale.png"), dpi=160)
    plt.close()

    plt.figure()
    plt.plot(xs, [mp_to_float(v) for v in ratio_e], marker="o", linewidth=1)
    plt.xlabel("n")
    plt.ylabel("E_n / A_n")
    plt.title("Dilemss error on RH scale")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "dilemss_error_RH_scale.png"), dpi=160)
    plt.close()

    plt.figure()
    plt.plot(xs[:-1], [mp_to_float(v) for v in W], marker="o", linewidth=1)
    plt.xlabel("n")
    plt.ylabel("W_n = V_n / log(p_n)^2")
    plt.title("Normalized weighted prime gaps")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "normalized_weighted_gaps.png"), dpi=160)
    plt.close()

    plt.figure()
    plt.plot([M for M, _ in running], [mp_to_float(v) for _, v in running], marker="o", linewidth=1)
    plt.xlabel("prefix length M")
    plt.ylabel("prefix K_P^RH")
    plt.title(f"Running K_P^RH, r <= {min(rmax, N-1)}")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "running_K_RH.png"), dpi=160)
    plt.close()

    result = ExperimentResult(primes, P, phi_p, phi_P, E, A, V, W)
    return {
        "result": result,
        "K_RH": K_RH,
        "arg_RH": arg_RH,
        "K_gaps": K_gaps,
        "outdir": outdir,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Dilemss numerical experiments")
    parser.add_argument("--N", type=int, default=100, help="number of primes")
    parser.add_argument("--rmax", type=int, default=20, help="maximum difference order")
    parser.add_argument("--precision", type=int, default=80, help="mpmath decimal precision")
    parser.add_argument("--outdir", type=str, default="dilemss_outputs", help="output directory")
    parser.add_argument("--alphas", type=float, nargs="+", default=[0.5, 1.0, 2.0], help="alpha values for gap norm")
    args = parser.parse_args()

    data = run_experiment(args.N, args.rmax, args.precision, args.outdir, args.alphas)
    print("Dilemss experiment complete")
    print(f"N={args.N}, rmax={min(args.rmax, args.N-1)}, precision={args.precision}")
    print(f"outputs={os.path.abspath(args.outdir)}")
    print(f"K_P^RH approx = {mp.nstr(data['K_RH'], 25)}")
    n0, r0, val0 = data["arg_RH"]
    print(f"  attained at n={n0}, r={r0}, signed value={mp.nstr(val0, 25)}")
    for alpha, (K_gap, arg_gap) in data["K_gaps"].items():
        n1, r1, val1 = arg_gap
        print(f"K_gap(alpha={alpha}) approx = {mp.nstr(K_gap, 25)}")
        print(f"  attained at n={n1}, r={r1}, signed value={mp.nstr(val1, 25)}")


if __name__ == "__main__":
    main()
